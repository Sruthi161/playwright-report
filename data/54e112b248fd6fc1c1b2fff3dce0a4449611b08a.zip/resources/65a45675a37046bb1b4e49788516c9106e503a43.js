function gaEventRegister_CR(_event){}

function gaEventRegister_LN(_event){}

function gaEventRegister(_event){}

function gaMGEventRegister(category, action, label, value){}